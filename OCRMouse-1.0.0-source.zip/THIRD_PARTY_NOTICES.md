# Third-party software

The Windows 64-bit add-on package bundles runtime libraries from the Python 3.13 environment used to build it:

- Pillow 12.3.0 — HPND License.
- Requests 2.34.2 — Apache-2.0 License.
- urllib3 2.8.0 — MIT License.
- certifi 2026.7.22 — Mozilla Public License 2.0.
- charset-normalizer 3.5.1 — MIT License.
- idna 3.20 — BSD 3-Clause License.

License texts are included under `globalPlugins/ocrMouse/_vendor/licenses/` in the source tree and in the add-on package.
