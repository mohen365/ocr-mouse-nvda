# -*- coding: utf-8 -*-
import sys
import os
import time
import io
import base64
import ctypes
import re
import json
import threading
from ctypes import wintypes

# --- 1. 动态添加依赖库路径 ---
cur_dir = os.path.dirname(__file__)
vendor_dir = os.path.join(cur_dir, "_vendor")
if vendor_dir not in sys.path:
    sys.path.insert(0, vendor_dir)

# --- 2. 尝试导入第三方库 ---
try:
    import requests
    from PIL import ImageGrab
    LIBS_OK = True
except ImportError:
    LIBS_OK = False
    requests = None
    ImageGrab = None

# --- 3. 尝试导入 wx ---
try:
    import wx
except ImportError:
    wx = None

# --- 4. 导入 NVDA 核心模块 ---
import globalPluginHandler
import ui
import speech
import winUser
import api
import gui
from scriptHandler import script
import config
import addonHandler
from gui.settingsDialogs import NVDASettingsDialog, SettingsPanel
from .secretStorage import encryptSecret, decryptSecret, SecretStorageError

addonHandler.initTranslation()

CONFIG_SECTION = "ocrMouse"
SECRET_KEYS = ("baiduApiKey", "baiduSecretKey", "dashscopeApiKey")
config.conf.spec[CONFIG_SECTION] = {key: "string(default='')" for key in SECRET_KEYS}


class OCRMouseSettingsPanel(SettingsPanel):
	title = _("OCR 鼠标增强")

	def makeSettings(self, sizer):
		helper = gui.guiHelper.BoxSizerHelper(self, sizer=sizer)
		helper.addItem(wx.StaticText(self, label=_(
			"在此配置百度 OCR 和阿里云视觉定位的 API 密钥。密钥使用 Windows 当前用户加密后保存。",
		)))
		self._controls = {}
		self._unreadable = {}
		labels = {
			"baiduApiKey": _("百度 OCR API Key"),
			"baiduSecretKey": _("百度 OCR Secret Key"),
			"dashscopeApiKey": _("阿里云 DashScope API Key（AI 视觉定位）"),
		}
		for key, label in labels.items():
			control = helper.addLabeledControl(label, wx.TextCtrl, style=wx.TE_PASSWORD)
			try:
				control.SetValue(decryptSecret(config.conf[CONFIG_SECTION].get(key, "")))
			except SecretStorageError:
				control.SetValue("")
				self._unreadable[key] = config.conf[CONFIG_SECTION].get(key, "")
				ui.message(_("已保存的密钥无法解密，请重新填写。"))
			self._controls[key] = control

	def onSave(self):
		for key, control in self._controls.items():
			value = control.GetValue().strip()
			if value:
				config.conf[CONFIG_SECTION][key] = encryptSecret(value)
			elif key in self._unreadable:
				config.conf[CONFIG_SECTION][key] = self._unreadable[key]
			else:
				config.conf[CONFIG_SECTION][key] = ""
		config.conf.save()

# ==========================================
# 辅助函数
# ==========================================
def get_window_rect_safe(hwnd):
    try:
        rect = wintypes.RECT()
        user32 = ctypes.windll.user32
        if user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return rect.left, rect.top, rect.right, rect.bottom
    except:
        pass
    return None

# ==========================================
# 插件主类
# ==========================================
class GlobalPlugin(globalPluginHandler.GlobalPlugin):

    def __init__(self):
        super(GlobalPlugin, self).__init__()
        if OCRMouseSettingsPanel not in NVDASettingsDialog.categoryClasses:
            NVDASettingsDialog.categoryClasses.append(OCRMouseSettingsPanel)
        self.mouseCheckTimer = None
        if wx:
            self.mouseCheckTimer = wx.Timer()
            self.mouseCheckTimer.Bind(wx.EVT_TIMER, self.onMouseCheck)
        
        self.ocr_cache = [] 
        self.last_spoken_text = ""
        self.last_spoken_bbox = None
        self.access_token = None
        self.token_expire_time = 0
        self.target_hwnd = 0 

    def terminate(self):
        self.stop_ocr_mode(silent=True)
        if OCRMouseSettingsPanel in NVDASettingsDialog.categoryClasses:
            NVDASettingsDialog.categoryClasses.remove(OCRMouseSettingsPanel)
        super(GlobalPlugin, self).terminate()

    def get_secret(self, key):
        try:
            return decryptSecret(config.conf[CONFIG_SECTION].get(key, ""))
        except SecretStorageError as error:
            raise RuntimeError(str(error))

    def stop_ocr_mode(self, silent=False):
        if self.mouseCheckTimer and self.mouseCheckTimer.IsRunning():
            self.mouseCheckTimer.Stop()
        self.ocr_cache = []
        self.last_spoken_text = ""
        self.last_spoken_bbox = None
        self.target_hwnd = 0
        if not silent:
            ui.message("OCR 读鼠标已退出")

    # ==================================================================
    # 功能模块 A：AI 视觉定位 (修复静音版)
    # ==================================================================
    
    # 模式 1: 弹窗输入 (NVDA + Shift + /)
    @script(
        description="弹窗输入描述，AI自动定位",
        category="OCR Mouse",
        gesture="kb:NVDA+shift+/"
    )
    def script_aiLocateDialog(self, gesture):
        if not LIBS_OK:
            ui.message("错误：缺少库。")
            return
        # 关键修复：使用 wx.CallAfter 将弹窗推迟到主循环执行
        # 这样脚本会立即结束，不会阻塞 NVDA 的语音处理
        wx.CallAfter(self._show_input_dialog)

    def _show_input_dialog(self):
        # 创建弹窗
        dlg = wx.TextEntryDialog(gui.mainFrame, "请输入要查找的按钮或图标名称：", "AI 视觉定位", "")
        
        # 显示弹窗 (此时 NVDA 应该已经准备好处理 UI 事件了)
        if dlg.ShowModal() == wx.ID_OK:
            query_text = dlg.GetValue()
            dlg.Destroy()
            # 获取输入后，立即开始处理
            self._start_ai_process(query_text)
        else:
            dlg.Destroy()

    # 模式 2: 剪贴板读取 (NVDA + Shift + Ctrl + /)
    # 备用方案：如果弹窗还是有问题，可以直接复制文字然后按这个键
    @script(
        description="读取剪贴板内容作为描述，AI自动定位",
        category="OCR Mouse",
        gesture="kb:NVDA+shift+control+/"
    )
    def script_aiLocateClipboard(self, gesture):
        if not LIBS_OK:
            ui.message("错误：缺少库。")
            return
        
        try:
            # 读取剪贴板
            text = api.getClipData()
            if not text or not isinstance(text, str) or not text.strip():
                ui.message("剪贴板为空或不是文字。")
                return
            
            # 取前 20 个字避免太长
            query_text = text.strip()[:50]
            self._start_ai_process(query_text)
            
        except Exception as e:
            ui.message(f"读取剪贴板失败: {str(e)}")

    # --- AI 处理核心逻辑 ---
    def _start_ai_process(self, query_text):
        if not query_text: return

        hwnd = winUser.getForegroundWindow()
        rect = get_window_rect_safe(hwnd)
        if not rect:
            ui.message("无法获取窗口范围。")
            return
        
        ui.message(f"正在寻找“{query_text}”，请稍候...")

        # 启动后台线程
        t = threading.Thread(target=self.ai_worker_thread, args=(hwnd, rect, query_text))
        t.daemon = True
        t.start()

    def ai_worker_thread(self, hwnd, rect, query_text):
        left, top, right, bottom = rect
        width = right - left
        height = bottom - top

        try:
            img = ImageGrab.grab(bbox=(left, top, right, bottom), all_screens=True)
            bbox_norm = self.call_qwen_vl(img, query_text)
            
            if not bbox_norm:
                wx.CallAfter(ui.message, f"AI 未能找到：{query_text}")
                return

            n_x1, n_y1, n_x2, n_y2 = bbox_norm
            abs_x1 = left + int((n_x1 / 1000.0) * width)
            abs_y1 = top + int((n_y1 / 1000.0) * height)
            abs_x2 = left + int((n_x2 / 1000.0) * width)
            abs_y2 = top + int((n_y2 / 1000.0) * height)
            
            center_x = (abs_x1 + abs_x2) // 2
            center_y = (abs_y1 + abs_y2) // 2

            wx.CallAfter(self.perform_mouse_move, center_x, center_y, query_text)

        except Exception as e:
            wx.CallAfter(ui.message, f"AI 错误: {str(e)}")

    def perform_mouse_move(self, x, y, text):
        winUser.setCursorPos(x, y)
        speech.speak(f"已定位到 {text}")

    def call_qwen_vl(self, image_obj, query):
        api_key = self.get_secret("dashscopeApiKey")
        if not api_key:
            raise RuntimeError("请先在 NVDA 设置的 OCR 鼠标增强页面填写 DashScope API Key。")
        url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation"
        buf = io.BytesIO()
        image_obj.save(buf, format='PNG')
        b64_str = base64.b64encode(buf.getvalue()).decode("utf-8")
        img_data = f"data:image/png;base64,{b64_str}"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        prompt_text = (
            f"请检测图中 UI 元素 '{query}' 的位置。"
            "请返回该元素的 Bounding Box，格式为 [xmin, ymin, xmax, ymax]，"
            "坐标范围请归一化到 0 到 1000 之间。"
            "请直接返回 JSON 格式的列表，不要包含任何其他解释文字。"
        )
        payload = {
            "model": "qwen-vl-max",
            "input": {
                "messages": [
                    {
                        "role": "user",
                        "content": [{"image": img_data}, {"text": prompt_text}]
                    }
                ]
            }
        }
        
        resp = requests.post(url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()

        if "output" in data and "choices" in data["output"]:
            content = data["output"]["choices"][0]["message"]["content"][0]["text"]
            match = re.search(r'\[(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\]', content)
            if match:
                return [int(match.group(1)), int(match.group(2)), int(match.group(3)), int(match.group(4))]
        return None

    # ==================================================================
    # 功能模块 B：OCR 读鼠标 (原有功能)
    # ==================================================================
    @script(
        description="OCR扫描当前窗口并开启鼠标跟随朗读",
        category="OCR Mouse",
        gesture="kb:NVDA+shift+,"
    )
    def script_ocrScan(self, gesture):
        if not LIBS_OK:
            ui.message("错误：requests 或 Pillow 库未加载。")
            return

        hwnd = winUser.getForegroundWindow()
        if not hwnd: return

        rect_tuple = get_window_rect_safe(hwnd)
        if not rect_tuple: return
        
        left, top, right, bottom = rect_tuple
        width = right - left
        height = bottom - top
        if width <= 0 or height <= 0: return

        self.stop_ocr_mode(silent=True)
        ui.message("正在OCR扫描...")
        self.target_hwnd = hwnd

        try:
            img = ImageGrab.grab(bbox=(left, top, right, bottom), all_screens=True)
            results = self.call_baidu_ocr(img)
            
            if not results or "words_result" not in results:
                ui.message("未识别到文字。")
                return

            words = results["words_result"]
            for item in words:
                txt = item["words"]
                loc = item["location"]
                self.ocr_cache.append({
                    "text": txt,
                    "bbox": (left + loc["left"], top + loc["top"], left + loc["left"] + loc["width"], top + loc["top"] + loc["height"])
                })

            if len(self.ocr_cache) > 0:
                ui.message(f"识别成功，鼠标模式已开启。")
                self.mouseCheckTimer.Start(50)
            else:
                ui.message("图片中没有文字。")
        except Exception as e:
            ui.message("OCR错误: " + str(e))

    @script(
        description="停止 OCR 鼠标朗读模式",
        category="OCR Mouse",
        gesture="kb:NVDA+shift+."
    )
    def script_ocrStop(self, gesture):
        self.stop_ocr_mode(silent=False)

    # --- 百度 OCR 相关函数 ---
    def get_baidu_token(self):
        api_key = self.get_secret("baiduApiKey")
        secret_key = self.get_secret("baiduSecretKey")
        if not api_key or not secret_key:
            raise RuntimeError("请先在 NVDA 设置的 OCR 鼠标增强页面填写百度 OCR API Key 和 Secret Key。")
        now = time.time()
        if self.access_token and now < self.token_expire_time:
            return self.access_token
        url = "https://aip.baidubce.com/oauth/2.0/token"
        params = {"grant_type": "client_credentials", "client_id": api_key, "client_secret": secret_key}
        res = requests.post(url, params=params, timeout=10)
        res.raise_for_status()
        data = res.json()
        if "access_token" in data:
            self.access_token = data["access_token"]
            self.token_expire_time = now + data.get("expires_in", 2592000) - 60
            return self.access_token
        raise Exception("Token获取失败")

    def call_baidu_ocr(self, image_obj):
        token = self.get_baidu_token()
        url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate"
        buf = io.BytesIO()
        image_obj.save(buf, format='PNG')
        b64_str = base64.b64encode(buf.getvalue()).decode("utf-8")
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {"image": b64_str}
        res = requests.post(f"{url}?access_token={token}", headers=headers, data=data, timeout=15)
        res.raise_for_status()
        return res.json()

    # --- 定时器回调 ---
    def onMouseCheck(self, evt):
        if not self.ocr_cache: return
        if winUser.getForegroundWindow() != self.target_hwnd:
            self.stop_ocr_mode(silent=True)
            return

        mx, my = winUser.getCursorPos()
        found = None
        for item in self.ocr_cache:
            x1, y1, x2, y2 = item["bbox"]
            if x1 <= mx < x2 and y1 <= my < y2:
                found = item
                break
        
        if found:
            if (found["text"] != self.last_spoken_text) or (found["bbox"] != self.last_spoken_bbox):
                speech.cancelSpeech()
                speech.speak(found["text"])
                self.last_spoken_text = found["text"]
                self.last_spoken_bbox = found["bbox"]
        else:
            if self.last_spoken_text:
                self.last_spoken_text = ""
                self.last_spoken_bbox = None
