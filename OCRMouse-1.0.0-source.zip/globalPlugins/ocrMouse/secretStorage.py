"""Windows DPAPI helpers for user-owned OCRMouse API credentials."""
import base64
import ctypes
from ctypes import wintypes

_CRYPTPROTECT_UI_FORBIDDEN = 0x01
_PREFIX = "dpapi:v1:"


class SecretStorageError(Exception):
	"""A credential could not be encrypted or decrypted for this Windows user."""


class _DataBlob(ctypes.Structure):
	_fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(wintypes.BYTE))]


def _bindings():
	crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
	kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
	protect = crypt32.CryptProtectData
	protect.argtypes = [ctypes.POINTER(_DataBlob), wintypes.LPCWSTR, ctypes.c_void_p,
		ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
	protect.restype = wintypes.BOOL
	unprotect = crypt32.CryptUnprotectData
	unprotect.argtypes = [ctypes.POINTER(_DataBlob), ctypes.c_void_p, ctypes.c_void_p,
		ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
	unprotect.restype = wintypes.BOOL
	free = kernel32.LocalFree
	free.argtypes = [wintypes.HLOCAL]
	free.restype = wintypes.HLOCAL
	return protect, unprotect, free


def _blob(data):
	buffer = ctypes.create_string_buffer(data)
	return _DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(wintypes.BYTE))), buffer


def encryptSecret(value):
	if not value:
		return ""
	try:
		protect, _, free = _bindings()
		inputBlob, inputBuffer = _blob(value.encode("utf-8"))
		outputBlob = _DataBlob()
		if not protect(ctypes.byref(inputBlob), "OCRMouse credential", None, None, None,
					   _CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(outputBlob)):
			raise ctypes.WinError(ctypes.get_last_error())
		try:
			cipher = ctypes.string_at(outputBlob.pbData, outputBlob.cbData)
			return _PREFIX + base64.b64encode(cipher).decode("ascii")
		finally:
			free(ctypes.cast(outputBlob.pbData, wintypes.HLOCAL))
			del inputBuffer
	except Exception as error:
		if isinstance(error, SecretStorageError):
			raise
		raise SecretStorageError("Windows could not protect this credential.") from error


def decryptSecret(value):
	if not value:
		return ""
	if not isinstance(value, str) or not value.startswith(_PREFIX):
		raise SecretStorageError("Credential is not protected with Windows DPAPI.")
	try:
		cipher = base64.b64decode(value[len(_PREFIX):], validate=True)
		_, unprotect, free = _bindings()
		inputBlob, inputBuffer = _blob(cipher)
		outputBlob = _DataBlob()
		if not unprotect(ctypes.byref(inputBlob), None, None, None, None,
						 _CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(outputBlob)):
			raise ctypes.WinError(ctypes.get_last_error())
		try:
			return ctypes.string_at(outputBlob.pbData, outputBlob.cbData).decode("utf-8")
		finally:
			free(ctypes.cast(outputBlob.pbData, wintypes.HLOCAL))
			del inputBuffer
	except Exception as error:
		if isinstance(error, SecretStorageError):
			raise
		raise SecretStorageError("Windows could not unprotect this credential.") from error
