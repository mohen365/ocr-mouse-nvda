# OCRMouse — OCR-enhanced mouse reading for NVDA

OCRMouse reads text that NVDA cannot expose to its normal object navigation when you point the mouse at it. It can also send a screenshot and a description to a vision service and move the mouse to the matching interface element.

## Shortcuts

- `NVDA+Shift+,` (main keyboard comma): scan the foreground window and start mouse-follow reading.
- `NVDA+Shift+.` (main keyboard period): stop mouse-follow reading.
- `NVDA+Shift+/`: describe an interface element to the vision model and move the pointer to it.
- `NVDA+Shift+Ctrl+/`: use clipboard text as the target description.

## Configure API credentials

Open **NVDA menu → Settings → OCRMouse**. Fill in the credentials for the services you use:

- Baidu OCR API Key and Secret Key for OCR text extraction.
- Alibaba Cloud DashScope API Key for visual element targeting.

Credential fields hide their contents. OCRMouse encrypts saved credentials with Windows DPAPI for the current Windows user and stores only the encrypted values in NVDA's configuration. Leaving a field blank and saving clears it. Moving the NVDA configuration to another Windows account will require entering the credentials again.

OCRMouse only sends a screenshot when you invoke the OCR or visual-targeting shortcut. Mouse-follow speech uses the OCR results already received and does not continuously upload the screen. Network traffic goes to Baidu OCR or Alibaba Cloud DashScope according to the shortcut and configured service.

## Requirements and packaging

- NVDA 2026.1 or later; tested with NVDA 2026.2 on Windows 64-bit.
- The add-on package bundles its Python runtime dependencies.
- Run `python build.py` to create `dist/OCRMouse-1.0.0.nvda-addon`.

OCRMouse is distributed under GNU GPL version 2 or (at your option) any later version. See `LICENSE` and `THIRD_PARTY_NOTICES.md`.
