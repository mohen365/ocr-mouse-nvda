from __future__ import annotations

import configparser
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIST = ROOT / "dist"
MANIFEST = ROOT / "manifest.ini"


def main() -> None:
	parser = configparser.ConfigParser()
	parser.read_string("[addon]\n" + MANIFEST.read_text(encoding="utf-8"))
	version = parser["addon"]["version"]
	if not re.fullmatch(r"\d+\.\d+(?:\.\d+)?", version):
		raise SystemExit("Invalid add-on version")

	plugin = ROOT / "globalPlugins" / "ocrMouse" / "__init__.py"
	source = plugin.read_text(encoding="utf-8")
	if "\ufffd" in source:
		raise SystemExit("Source contains invalid replacement characters")
	for name in ("BAIDU_API_KEY", "BAIDU_SECRET_KEY", "DASHSCOPE_API_KEY"):
		if re.search(rf"^{name}\s*=\s*['\"]\s*[^'\"]", source, flags=re.M):
			raise SystemExit(f"Hard-coded credential found in {name}")
	if "verify=False" in source:
		raise SystemExit("TLS certificate validation must remain enabled")

	DIST.mkdir(exist_ok=True)
	output = DIST / f"OCRMouse-{version}.nvda-addon"
	excluded = {"__pycache__"}
	with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
		paths = [ROOT / name for name in (
			"manifest.ini", "README.md", "LICENSE", "THIRD_PARTY_NOTICES.md",
		)]
		for directory in (ROOT / "globalPlugins", ROOT / "doc"):
			paths.extend(directory.rglob("*"))
		for path in paths:
			if not path.is_file() or any(part in excluded for part in path.parts):
				continue
			if path.suffix in {".pyc", ".pyy"}:
				continue
			archive.write(path, path.relative_to(ROOT).as_posix())
	print(output)


if __name__ == "__main__":
	main()
